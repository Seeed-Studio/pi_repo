var searchData=
[
  ['terasic_20de10_2dnano',['Terasic DE10-Nano',['../de10-nano.html',1,'']]],
  ['testing_20mraa',['Testing mraa',['../md_docs_testing.html',1,'']]],
  ['timestamp',['timestamp',['../structmraa__gpio__event.html#a49eee8d3201859fda92f5e120c4fe7ff',1,'mraa_gpio_event::timestamp()'],['../structiio__event__data.html#ad4c7a6ce31d604096b26394249cd8a78',1,'iio_event_data::timestamp()']]],
  ['transfer',['transfer',['../classmraa_1_1_spi.html#a003b7c1aba817079a67359fc89419421',1,'mraa::Spi']]],
  ['transfer_5fword',['transfer_word',['../classmraa_1_1_spi.html#a1018b63e46bd81cf6953ad2887659c83',1,'mraa::Spi']]],
  ['trigger',['trigger',['../classmraa_1_1_led.html#a93e8aa0f108d998164d9ecfdb544f52b',1,'mraa::Led']]],
  ['type',['type',['../structmraa__iio__channel.html#a23506fc4821ab6d9671f3e6222591a96',1,'mraa_iio_channel::type()'],['../structmraa_1_1_iio_event_data.html#ac765329451135abec74c45e1897abf26',1,'mraa::IioEventData::type()']]],
  ['types_2eh',['types.h',['../types_8h.html',1,'']]],
  ['types_2ehpp',['types.hpp',['../types_8hpp.html',1,'']]]
];
