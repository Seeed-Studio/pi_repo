var searchData=
[
  ['a96boards',['A96BOARDS',['../namespacemraa.html#a5be836f305c9cd8b44ffb7c964f4cbd9a4c0dc4b74dfc5f87a86e2788f269b070',1,'mraa']]],
  ['adcrawbits',['adcRawBits',['../namespacemraa.html#a90fde4676a919121fe6b791d89bbd77e',1,'mraa']]],
  ['adcsupportedbits',['adcSupportedBits',['../namespacemraa.html#aab42dc89e7de2ebb8c7530c4868bc933',1,'mraa']]],
  ['address',['address',['../classmraa_1_1_i2c.html#af4cae0d9a992c15d580b8c19c2554418',1,'mraa::I2c']]],
  ['addsubplatform',['addSubplatform',['../namespacemraa.html#a9d312446120a495bfcdef40c8f8a5846',1,'mraa']]],
  ['aio',['Aio',['../classmraa_1_1_aio.html',1,'Aio'],['../classmraa_1_1_aio.html#ae9380fdbc8e082272edee3cd59d7e90a',1,'mraa::Aio::Aio(int pin)'],['../classmraa_1_1_aio.html#a8dc7976ce70e123831817c9c02e45b61',1,'mraa::Aio::Aio(void *aio_context)']]],
  ['aio_2eh',['aio.h',['../aio_8h.html',1,'']]],
  ['android_5fperipheralmanager',['ANDROID_PERIPHERALMANAGER',['../namespacemraa.html#a5be836f305c9cd8b44ffb7c964f4cbd9a6cd29b26c99299f7dfa6e7698d098cfc',1,'mraa']]]
];
