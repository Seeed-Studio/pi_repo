var searchData=
[
  ['changelog',['Changelog',['../changelog.html',1,'']]],
  ['channel',['channel',['../structmraa_1_1_iio_event_data.html#adf7dff2c57c0da9a4a2b70e3e815be31',1,'mraa::IioEventData']]],
  ['channel2',['channel2',['../structmraa_1_1_iio_event_data.html#a556fbbd314f244452213081bd57ef067',1,'mraa::IioEventData']]],
  ['channeltype',['channelType',['../structmraa_1_1_iio_event_data.html#ace71eb2c5fd1fa79b9c055024bc276d4',1,'mraa::IioEventData']]],
  ['cleartrigger',['clearTrigger',['../classmraa_1_1_led.html#a2fe0547e7c4c06e2eadebd37a5d9a45d',1,'mraa::Led']]],
  ['command',['command',['../classmraa_1_1_uart_o_w.html#af769b00cc057841c0e3e3a50f5af6d32',1,'mraa::UartOW::command(uint8_t command, uint8_t *id)'],['../classmraa_1_1_uart_o_w.html#a7066239f9baed507aad878cc2047349e',1,'mraa::UartOW::command(uint8_t command, std::string id)']]],
  ['common_2eh',['common.h',['../common_8h.html',1,'']]],
  ['common_2ehpp',['common.hpp',['../common_8hpp.html',1,'']]],
  ['contributing_20to_20libmraa',['Contributing to libmraa',['../contributing.html',1,'']]],
  ['crc8',['crc8',['../classmraa_1_1_uart_o_w.html#ac51fb7b6ab03893f85bc5b755d546de7',1,'mraa::UartOW::crc8(uint8_t *buffer, uint16_t length)'],['../classmraa_1_1_uart_o_w.html#acc0f3a816b7b59b928436e8c1767a225',1,'mraa::UartOW::crc8(std::string buffer)']]]
];
