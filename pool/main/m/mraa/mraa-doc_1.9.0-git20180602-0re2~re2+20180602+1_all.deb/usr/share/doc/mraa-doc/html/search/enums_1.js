var searchData=
[
  ['edge',['Edge',['../namespacemraa.html#a5be7c8fa582f7b873d1c6caacb633073',1,'mraa']]]
];
