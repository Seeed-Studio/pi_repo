var searchData=
[
  ['changelog',['Changelog',['../changelog.html',1,'']]],
  ['contributing_20to_20libmraa',['Contributing to libmraa',['../contributing.html',1,'']]]
];
