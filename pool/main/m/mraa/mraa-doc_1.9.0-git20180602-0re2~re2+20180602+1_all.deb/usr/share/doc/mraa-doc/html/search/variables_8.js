var searchData=
[
  ['offset',['offset',['../structmraa__iio__channel.html#a29b5297d3393519050e3126c4cb07c1c',1,'mraa_iio_channel']]]
];
