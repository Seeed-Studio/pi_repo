var searchData=
[
  ['shift',['shift',['../structmraa__iio__channel.html#a879322fd39731501f6891c8ea3dd6e9d',1,'mraa_iio_channel']]],
  ['signedd',['signedd',['../structmraa__iio__channel.html#a595b8f3da6ade77c27c3fe1a8d30104c',1,'mraa_iio_channel']]]
];
