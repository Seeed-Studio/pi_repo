var searchData=
[
  ['timestamp',['timestamp',['../structmraa__gpio__event.html#a49eee8d3201859fda92f5e120c4fe7ff',1,'mraa_gpio_event::timestamp()'],['../structiio__event__data.html#ad4c7a6ce31d604096b26394249cd8a78',1,'iio_event_data::timestamp()']]],
  ['type',['type',['../structmraa__iio__channel.html#a23506fc4821ab6d9671f3e6222591a96',1,'mraa_iio_channel::type()'],['../structmraa_1_1_iio_event_data.html#ac765329451135abec74c45e1897abf26',1,'mraa::IioEventData::type()']]]
];
