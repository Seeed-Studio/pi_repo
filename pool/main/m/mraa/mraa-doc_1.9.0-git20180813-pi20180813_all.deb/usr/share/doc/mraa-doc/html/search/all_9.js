var searchData=
[
  ['hassubplatform',['hasSubPlatform',['../namespacemraa.html#a4d57a23573a0ece1ea23ad463dbce299',1,'mraa']]]
];
