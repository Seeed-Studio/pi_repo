var searchData=
[
  ['bits_5fused',['bits_used',['../structmraa__iio__channel.html#a9c67a09cb5ae030c254f2582bc476f3c',1,'mraa_iio_channel']]],
  ['bytes',['bytes',['../structmraa__iio__channel.html#a1169e7a0ccc997c70b4d09a87bfc4eec',1,'mraa_iio_channel']]]
];
