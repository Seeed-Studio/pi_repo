var searchData=
[
  ['name',['name',['../structmraa__iio__event.html#a5ac083a645d964373f022d03df4849c8',1,'mraa_iio_event']]]
];
