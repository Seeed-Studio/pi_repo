var searchData=
[
  ['spi_5fmode',['Spi_Mode',['../namespacemraa.html#a755e9f6ea01685e1480f94bfae41725d',1,'mraa']]]
];
