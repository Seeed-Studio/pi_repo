var searchData=
[
  ['mock_20platform',['Mock platform',['../mock.html',1,'']]],
  ['mraa_20npm_20pkg',['mraa NPM pkg',['../npmpkg.html',1,'']]]
];
