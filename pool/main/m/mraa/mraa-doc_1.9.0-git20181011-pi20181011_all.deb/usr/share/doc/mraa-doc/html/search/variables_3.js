var searchData=
[
  ['enabled',['enabled',['../structmraa__iio__channel.html#a03e6cca0c879c0443efb431c30c14f76',1,'mraa_iio_channel::enabled()'],['../structmraa__iio__event.html#a03e6cca0c879c0443efb431c30c14f76',1,'mraa_iio_event::enabled()']]]
];
