var searchData=
[
  ['pinmodes',['Pinmodes',['../namespacemraa.html#aeebb83211aa93c60a318816d27dda010',1,'mraa']]],
  ['platform',['Platform',['../namespacemraa.html#a5be836f305c9cd8b44ffb7c964f4cbd9',1,'mraa']]]
];
