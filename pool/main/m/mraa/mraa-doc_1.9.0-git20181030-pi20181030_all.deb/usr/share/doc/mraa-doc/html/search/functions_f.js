var searchData=
[
  ['transfer',['transfer',['../classmraa_1_1_spi.html#a003b7c1aba817079a67359fc89419421',1,'mraa::Spi']]],
  ['transfer_5fword',['transfer_word',['../classmraa_1_1_spi.html#a1018b63e46bd81cf6953ad2887659c83',1,'mraa::Spi']]],
  ['trigger',['trigger',['../classmraa_1_1_led.html#a93e8aa0f108d998164d9ecfdb544f52b',1,'mraa::Led']]]
];
