var searchData=
[
  ['diff',['diff',['../structmraa_1_1_iio_event_data.html#a65f3a8178e1f997a7a19a988bb0f4e1a',1,'mraa::IioEventData']]],
  ['direction',['direction',['../structmraa_1_1_iio_event_data.html#a886d551d5381dc3e53f17825ffc51641',1,'mraa::IioEventData']]]
];
